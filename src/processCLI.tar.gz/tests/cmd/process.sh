


echo $1 $2 $3 $4
sleep 30
echo "sleep passed"
